<?php
// Silence is golden.

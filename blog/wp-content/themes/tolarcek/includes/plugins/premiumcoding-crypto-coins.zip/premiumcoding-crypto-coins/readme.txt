=== PremiumCoding Crypto Coins ===
Contributors: PremiumCoding
Donate link: 
Tags: bitcoin, cryptocurrency, bitcoin, ethereum, ripple, exchange, prices, rates, trading, payments, orders, token, btc, eth, etc, dash, nmc, nvc, ppc, dsh, candlestick, usd, eur  
Requires at least: 3.0
Tested up to: 4.9.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cryptocurrency features: displaying prices and exchange rates, candlestick price chart, calculator, accepting orders and payments, accepting donations.

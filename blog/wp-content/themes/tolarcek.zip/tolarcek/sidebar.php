<?php if(is_active_sidebar( 'tolarcek_sidebar' )) { ?>
	<div class="sidebar">	
		<?php dynamic_sidebar( 'tolarcek_sidebar' ); ?>
	</div>
<?php } ?>

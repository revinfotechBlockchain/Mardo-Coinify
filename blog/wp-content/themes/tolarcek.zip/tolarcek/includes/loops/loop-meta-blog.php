<?php if(tolarcek_globals('display_socials') && !is_single()) { ?>
	<div class="blog_social"> <?php tolarcek_socialLinkSingle(get_the_permalink(),get_the_title())  ?></div>
<?php } ?>
<!-- end of socials -->
<!-- end of post meta -->	